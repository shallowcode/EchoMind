# Jev 1.13 与 GLM-4.5-Air：意图识别对照

状态：completed

固定 48 条，中英文各 24 条，退款/发票/订单状态/转人工各 12 条。候选类别仍为 19 类。
主指标比较原方案的模型语义分类分支；融合规则结果另列诊断，不作为公平校准后的结论。

| 分组 | 方案 | N | 正确率 | Macro-F1 | 中位延迟 ms | P95 ms | 失败率 |
|---|---|---:|---:|---:|---:|---:|---:|
| all | glm | 48 | 77.1% | 0.860 | 655 | 800 | 0.0% |
| all | jev | 48 | 85.4% | 0.916 | 976 | 1048 | 0.0% |
| zh | glm | 24 | 91.7% | 0.955 | 643 | 733 | 0.0% |
| zh | jev | 24 | 91.7% | 0.955 | 989 | 1035 | 0.0% |
| en | glm | 24 | 62.5% | 0.682 | 666 | 800 | 0.0% |
| en | jev | 24 | 79.2% | 0.852 | 970 | 1048 | 0.0% |

配对统计：`{"n_pairs": 48, "jev_only_correct": 4, "glm_only_correct": 0, "accuracy_delta": 0.08333333333333333, "paired_bootstrap_95": [0.020833333333333332, 0.16666666666666666], "mcnemar_exact_p": 0.125}`

OpenRouter 返回费用：$0.00198929；GLM 历史价目表估算：¥0.023086。
保守预算占用（不是实际美元账单）：$0.045993 / $0.45，另留 $0.05 余量。

## 限制

- Small exploratory set, not an independently adjudicated blind test
- Chinese labels authored before inference; English labels mapped from existing corpus
- Only four ground-truth classes; both models choose among all 19 production labels
- GLM direct China endpoint vs Jev via OpenRouter: latency includes provider/network differences
- GLM keeps original prompt and 256-token generation cap; Jev uses the same examples with typed choice
- No paid judge, retries, warmup, cross-model fallback, or confidence tuning
- Primary score is raw semantic branch; fusion diagnostic retains heuristic rules with non-equivalent confidence sources
- Cost estimate is not an invoice; GLM CNY tariff recorded by project on 2026-09-08, cache discounts excluded
- Budget treats GLM rates as USD at inflated 1.2/8 per million; uncertain requests retain reservation
